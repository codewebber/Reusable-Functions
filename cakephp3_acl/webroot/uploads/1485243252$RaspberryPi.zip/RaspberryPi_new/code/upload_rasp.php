<?php
$response = array();
require_once __DIR__ . '/db_connect.php';
$db = new DB_CONNECT();

$data = array();
$tableName = $_GET['tableName'];
$last_update = trim($_GET['last_update']); /* last sync time */
date_default_timezone_set('Asia/Calcutta');
$date = date('Y-m-d H:i:s');
	if($last_update != 0)
	{
	  if($tableName == "tbl_pathway" || $tableName == "tbl_scores")
	  {
		 $sql = 'select * from '. $tableName .' WHERE updated >="'.$last_update .'"';
	  }
	 else if($tableName == "tbl_quiz_dates")
	 {
		$sql = 'select * from '. $tableName .' WHERE created >="'.$last_update .'"';
	 }
	 else
	 {
		$sql = "select * from ". $tableName;
	 }
	}
	else
	{
		$sql = "select * from ". $tableName;

	}
	//echo $sql;exit;
	$query = mysql_query($sql);
	while ($row = mysql_fetch_assoc($query)) {	
		$response[] = $row;
	}
	
	//echo '<pre>'; print_r($response); echo '</pre>';
	
	$data['products'] = $response;
	$data['tableName'] = $tableName;
	$data['update_date'] = $date;
	$data['success'] = 1;
	echo json_encode($data);


?>
