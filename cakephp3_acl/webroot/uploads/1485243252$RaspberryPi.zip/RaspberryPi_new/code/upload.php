<?php
$response = array();
require_once __DIR__ . '/db_connect.php';
$db = new DB_CONNECT();
date_default_timezone_set('Asia/Calcutta');
$current_date = date('Y-m-d H:i:s');

$tableName = $_GET['tableName'];
$current_date = $_GET['current_date'];

if($tableName == "tbl_pathway") {
	$id = $_GET["id"];
	$userid = $_GET["userid"];
	$subject_name = $_GET["subject_name"];
	$program_name = $_GET["program_name"];
	$level_name = $_GET["level_name"];
	$lesson_name = $_GET["lesson_name"];
	$brick_level = $_GET["brick_level"];
	$date_val = $_GET["date_val"];
	$lesson_no = $_GET["lesson_no"];
	$updated = $_GET['date'];
	$last_update = $_GET['last_update'];
	$status = $_GET['status'];
	
	if($last_update!=0) {
		$result1 = mysql_query("SELECT * FROM tbl_pathway WHERE userid='$userid'");
		$num_rows1 = mysql_num_rows($result1);
		if($num_rows1>0) {
			//pathway exists
			while ($row = mysql_fetch_array($result1)) {
				
				if($last_update>=$row["updated"]) {
					$result = mysql_query("Update tbl_pathway set subject_name='$subject_name',program_name='$program_name',level_name='$level_name',lesson_name='$lesson_name',brick_level='$brick_level',dateVal='$date_val',lesson_no='$lesson_no',status='$status',updated='$current_date' where userid='$userid'");
					if (!mysql_error()) {
						$response["success"] = 1;
						$response["message"] = "Row updated";
					}
					else {
						$response["success"] = 0;
						$response["message"] = "Row updation failed";
					}
				}
				else {
					$response["success"] = 1;
					$response["message"] = "No action required";
				}
			}		
		}
		else {
			//add new pathway		
			$result = mysql_query("INSERT INTO tbl_pathway (userid, subject_name, program_name, level_name, lesson_name, brick_level, dateVal, lesson_no, updated, status) VALUES ('$userid', '$subject_name', '$program_name', '$level_name', '$lesson_name', '$brick_level', '$date_val', '$lesson_no','$current_date','$status')");	
			if($result) {
				$response["success"] = 1;
				$response["message"] = "Row added";
			}
			else {
				$response["success"] = 0;
				$response["message"] = "Row addition failed";
			}
			
		}
	}	
}	
elseif($tableName == "tbl_scores") {
	$id = $_GET["id"];
	$userid = $_GET["userid"];
	$subject_name = $_GET["subject_name"];
	$program_name = $_GET["program_name"];
	$level_name = $_GET["level_name"];
	$lesson_name = $_GET["lesson_name"];
	$lesson_no = $_GET["lesson_no"];
	$score = $_GET["score"];
	$last_update = $_GET['last_update'];
	$updated = $_GET['date'];
	$start_date = $_GET['start_date'];
	$attempt_date = $_GET['attempt_date'];
	$max_marks = $_GET['max_marks'];
	$status = $_GET['status'];
	$pass_status = $_GET['pass_status'];
	$time = $_GET['time'];
	$brick_id = $_GET['brick_id'];
	
	if($last_update!=0) {
		$result1 = mysql_query("SELECT * FROM tbl_scores WHERE userid='$userid' AND subject_name='$subject_name' AND program_name='$program_name' AND level_name='$level_name' AND lesson_name='$lesson_name' AND lesson_no='$lesson_no' AND score='$score' AND start_date='$start_date' AND attempt_date='$attempt_date' AND max_marks='$max_marks' AND pass_status='$pass_status' AND time='$time' AND brick_id='$brick_id'");
		$num_rows1 = mysql_num_rows($result1);
		if($num_rows1>0) {
			//score exists
			$response["success"] = 1;
			$response["message"] = "No action required";
			
		}
		else {
			//add new score		
			$result = mysql_query("INSERT INTO tbl_scores (userid, subject_name, program_name, level_name, lesson_name, lesson_no, score, updated, start_date, attempt_date, max_marks, status, pass_status, time, brick_id) VALUES ('$userid','$subject_name','$program_name','$level_name','$lesson_name','$lesson_no','$score','$current_date','$start_date','$attempt_date','$max_marks','$status','$pass_status','$time','$brick_id')");	
			if($result) {
				$response["success"] = 1;
				$response["message"] = "Row added";
			}
			else {
				$response["success"] = 0;
				$response["message"] = "Row addition failed";
			}
			
		}
	}
}
else if($tableName == "tbl_quiz_dates") {
	$id = $_GET["id"];
	$userid = $_GET["userid"];
	$subject_name = $_GET["subject_name"];
	$program_name = $_GET["program_name"];
	$level_name = $_GET["level_name"];
	$lesson_name = $_GET["lesson_name"];
	$lesson_no = $_GET["lesson_no"];
	$start_date = $_GET['start_date'];
	$attempt_date = $_GET['attempt_date'];
	$status = $_GET['status'];
	$last_update = $_GET['last_update'];
	$created = $_GET["created"];
	
	if($last_update!=0) {
		$result1 = mysql_query("SELECT * FROM tbl_quiz_dates WHERE userid='$userid'");
		$num_rows1 = mysql_num_rows($result1);
		if($num_rows1>0) {
			//quiz dates exists
				 while ($row = mysql_fetch_array($result1)) {
					 if($last_update>=$row["created"]) {
				$result = mysql_query("Update tbl_quiz_dates set subject_name='$subject_name',program_name='$program_name',level_name='$level_name',lesson_name='$lesson_name',lesson_no='$lesson_no',start_date='$start_date',attempt_date='$attempt_date',status='$status',created='$created' where userid='$userid'");
					if (!mysql_error()) {
						$response["success"] = 1;
						$response["message"] = "Row updated";
					}
					else {
						$response["success"] = 0;
						$response["message"] = "Row updation failed";
					}
				    }
				   else
				   {
					 $response["success"] = 1;
                                         $response["message"] = "No action required";
	
				   }
				
				}
		}
		else {
			//add new quiz dates		
			$result = mysql_query("INSERT INTO tbl_quiz_dates (userid, subject_name, program_name, level_name, lesson_name, lesson_no, start_date, attempt_date, status, created) VALUES ('$userid', '$subject_name', '$program_name', '$level_name', '$lesson_name', '$lesson_no', '$start_date', '$attempt_date', '$status', '$created')");	
			if($result) {
				$response["success"] = 1;
				$response["message"] = "Row added";
			}
			else {
				$response["success"] = 0;
				$response["message"] = "Row addition failed";
			}
			
		}
	}
		
}


echo json_encode($response);

?>
