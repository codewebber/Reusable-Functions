<?php
$target_path1 = "Files/";
/* Add the original filename to our target path.
Result is "uploads/filename.extension" */
$target_path1 = $target_path1 . basename( urldecode($_FILES['uploaded_file']['name']));
	$my_file = 'file2.txt';
 			$handle = fopen($my_file, 'a');
			fwrite($handle, "Action urlllllll::".$target_path1."---".urldecode($_FILES['uploaded_file']['name']));
 			fclose($handle);
if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $target_path1)) {
    echo "The first file ".  basename( $_FILES['uploaded_file']['name']).
    " has been uploaded.";
} else{
    echo "There was an error uploading the file, please try again!";
    echo "filename: " .  basename( $_FILES['uploaded_file']['name']);
    echo "target_path: " .$target_path1;
}
?>