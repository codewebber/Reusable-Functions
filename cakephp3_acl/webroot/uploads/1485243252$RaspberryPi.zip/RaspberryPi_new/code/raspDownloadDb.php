<?php
// include db connect class
require_once __DIR__ . '/db_connect.php';
$response = array();

// connecting to db
$db = new DB_CONNECT();
date_default_timezone_set('Asia/Calcutta');
$current_date = date('Y-m-d H:i:s');

if(isset($_GET["tableDelete"])){
        mysql_query("DELETE FROM tbl_pods");
        mysql_query("DELETE FROM tbl_levels");
        mysql_query("DELETE FROM tbl_subjects");
        mysql_query("DELETE FROM tbl_ques_template");
        mysql_query("DELETE FROM tbl_passscore");
        mysql_query("DELETE FROM tbl_quiz_dates");
        mysql_query("DELETE FROM tbl_brick_type");
}

if (isset($_GET["tableName"])) {
        $tableName = $_GET["tableName"];
	$current_date = $_GET["current_date"];

        if($tableName == "tbl_students") {
                $id = $_GET["id"];
                $student_name = $_GET["student_name"];
                $username = $_GET["username"];
                $password = $_GET["password"];
		$last_sync_time = $_GET["last_sync_time"];
		if(isset($_GET["last_sync_time"]) && $last_sync_time != 0)
		{
			$result = mysql_query("SELECT * FROM tbl_students WHERE id='$id'");
			$num_rows = mysql_num_rows($result);
			if($num_rows>0) 
            {
				while ($row = mysql_fetch_array($result)) 
                {
				  if($last_sync_time >= $row["updated"]) 
                  {
					 mysql_query("Update tbl_students set student_name='$student_name',username='$username',password='$password','updated'='$current_date' where id='$id'");
                                        
                        $response["success"] = 1;
                        $response["message"] = "Row updated";
				  }
                  else
                  {
                        //student exists
                        $response["success"] = 1;
                        $response["message"] = "No action required";
                  }
			   }
                        	
           }
           else
           {
                $result = mysql_query("INSERT INTO tbl_students (id,student_name,username,password,updated) VALUES ('$id','$student_name','$username','$password','$current_date')");
                if ($result) 
                {
                    $response["success"] = 1;
                } else 
                {
                    $response["success"] = 0;
                }
           }
			
		}         
    }

        elseif($tableName == "tbl_pods") {
                $id = $_GET["id"];
                $pod_name = $_GET["pod_name"];
                $country = $_GET["country"];
                $state = $_GET["state"];
                $region = $_GET["region"];
                $cluster = $_GET["cluster"];
                $password = $_GET["password"];
                $result = mysql_query("INSERT INTO tbl_pods (id,pod_name,country,state,region,cluster,password) VALUES ('$id','$pod_name','$country','$state','$region','$cluster','$password')");
                if ($result) {
                                $response["success"] = 1;
                                echo json_encode($response);
                        } else {
                                $response["success"] = 0;
                                echo json_encode($response);
                }
        }

        elseif($tableName == "tbl_subjects") {
                $id = $_GET["id"];
                $subject_name = $_GET["subject_name"];
                $result = mysql_query("INSERT INTO tbl_subjects (id,subject_name) VALUES ('$id','$subject_name')");
                if ($result) {
                                $response["success"] = 1;
                                echo json_encode($response);
                        } else {
                                $response["success"] = 0;
                                echo json_encode($response);
                }
        }
        elseif($tableName == "tbl_brick_type") {
                $id = $_GET["id"];
                $name = $_GET["name"];
                $type = $_GET["type"];
                $scorable = $_GET["scorable"];
                $result = mysql_query("INSERT INTO tbl_brick_type (id,name,type,scorable) VALUES ('$id','$name','$type','$scorable')");
                if ($result) {
                                $response["success"] = 1;
                               // echo json_encode($response);
                        } else {
                                $response["success"] = 0;
                               // echo json_encode($response);
                }
        }
        elseif($tableName == "tbl_programs") {
                $id = $_GET["id"];
                $subject_name = $_GET["subject_name"];
                $program_name = $_GET["program_name"];
                $last_sync_time = $_GET["last_sync_time"];
                $result = mysql_query("SELECT * FROM tbl_programs WHERE id='$id'");
                $num_rows = mysql_num_rows($result);
                if($num_rows>0) 
                {
                    while ($row = mysql_fetch_array($result)) 
                    {
                      if($last_sync_time >= $row["updated"]) 
                      {
                         mysql_query("Update tbl_programs set subject_name='$subject_name',program_name='$program_name',updated'='$current_date' where id='$id'");
                                            
                            $response["success"] = 1;
                            $response["message"] = "Row updated";
                      }
                      else
                      {
                            //program exists
                            $response["success"] = 1;
                            $response["message"] = "No action required";
                      }
                   }
                                
               }
               else
               {
                    $result = mysql_query("INSERT INTO tbl_programs (id,subject_name,program_name,updated) VALUES ('$id','$subject_name','$program_name','$current_date')");
                    if ($result) 
                    {
                        $response["success"] = 1;
                    } 
                    else 
                    {
                    
			   echo mysql_error();
			    $response["success"] = 0;
                    }
               }
        }
        elseif($tableName == "tbl_levels") {
                $id = $_GET["id"];
                $program_id = $_GET["program_id"];
                $subject_name = $_GET["subject_name"];
                $program_name = $_GET["program_name"];
                $level_name = $_GET["level_name"];
                $result = mysql_query("INSERT INTO tbl_levels (id,program_id,subject_name,program_name,level_name) VALUES ('$id','$program_id','$subject_name','$program_name','$level_name')");
                if ($result) {
                                $response["success"] = 1;
                                echo json_encode($response);
                        } else {
                                $response["success"] = 0;
                                echo json_encode($response);
                }
  }
        elseif($tableName == "tbl_lessons") {
                $id = $_GET["id"];
                $subject_name = $_GET["subject_name"];
                $program_name = $_GET["program_name"];
                $level_name = $_GET["level_name"];
                $lesson_name = $_GET["lesson_name"];
                $lesson_no = $_GET["lesson_no"];
                $last_sync_time = $_GET["last_sync_time"];
                $result = mysql_query("SELECT * FROM tbl_lessons WHERE id='$id'");
                $num_rows = mysql_num_rows($result);
                if($num_rows>0) 
                {
                    while ($row = mysql_fetch_array($result)) 
                    {
                      if($last_sync_time >= $row["updated"]) 
                      {
                         mysql_query("Update tbl_lessons set subject_name='$subject_name',program_name='$program_name',level_name='$level_name',updated'='$current_date',lesson_name = '$lesson_name',lesson_no = '$lesson_no' where id='$id'");
                                            
                            $response["success"] = 1;
                            $response["message"] = "Row updated";
                      }
                      else
                      {
                            //lesson exists
                            $response["success"] = 1;
                            $response["message"] = "No action required";
                      }
                   }
                                
               }
               else
               {
                    $result = mysql_query("INSERT INTO tbl_lessons (id,subject_name,program_name,level_name,lesson_name,lesson_no,updated) VALUES ('$id','$subject_name','$program_name','$level_name','$lesson_name','$lesson_no','$current_date')");
                            if ($result) {
                                    $response["success"] = 1;
                                    echo json_encode($response);
                            } else {
                                    $response["success"] = 0;
                                    echo json_encode($response);
                    }
               }
        }
        elseif($tableName == "tbl_bricks") {
                $id = $_GET["id"];
                $lesson_id = $_GET["lesson_id"];
                $btype_id = $_GET["btype_id"];
                $btype_value = $_GET["btype_value"];
                $brick_name = $_GET["brick_name"];
                $brick_value = $_GET["brick_value"];
                $package_name = $_GET["package_name"];
                $last_sync_time = $_GET["last_sync_time"];
                $result = mysql_query("SELECT * FROM tbl_bricks WHERE id='$id'");
                $num_rows = mysql_num_rows($result);
                if($num_rows>0) 
                {
                    while ($row = mysql_fetch_array($result)) 
                    {
                      if($last_sync_time >= $row["updated"]) 
                      {
                         mysql_query("Update tbl_bricks set lesson_id='$lesson_id',btype_id='$btype_id',btype_value='$btype_value',updated'='$current_date',brick_name = '$brick_name',brick_value = '$brick_value',package_name = '$package_name' where id='$id'");
                                            
                            $response["success"] = 1;
                            $response["message"] = "Row updated";
                      }
                      else
                      {
                            //lesson exists
                            $response["success"] = 1;
                            $response["message"] = "No action required";
                      }
                   }
                                
               }
               else
               {
                    $result = mysql_query("INSERT INTO tbl_bricks (id,lesson_id,brick_name,brick_value,btype_id,btype_value,package_name,updated) VALUES ('$id','$lesson_id','$brick_name','$brick_value','$btype_id','$btype_value', '$package_name','$current_date')");
                    if ($result) 
                    {
                        $response["success"] = 1;
                    } else 
                    {
                        $response["success"] = 0;
                    }
            }
        }
        elseif($tableName == "tbl_ques_template") {
                $id = $_GET["id"];
                $subject_name = $_GET["subject_name"];
                $program_name = $_GET["program_name"];
                $level_name = $_GET["level_name"];
                $lesson_name = $_GET["lesson_name"];
                $template_name = $_GET["template_name"];
                $question_no = $_GET["question_no"];
                $brick_name = $_GET["brick_name"];
                $result = mysql_query("INSERT INTO tbl_ques_template (id,subject_name,program_name,level_name,lesson_name,template_name,question_no,brick_name) VALUES ('$id','$subject_name','$program_name','$level_name','$lesson_name','$template_name','$question_no','$brick_name')");
                if ($result) {
                                $response["success"] = 1;
                                echo json_encode($response);
                        } else {
                                $response["success"] = 0;
                                echo json_encode($response);
                }
        }
        elseif($tableName == "tbl_questions") {
                $id = $_GET["id"];
                $ques_id = $_GET["ques_id"];
                $program_name = $_GET["program_name"];
                $level_name = $_GET["level_name"];
                $lesson_name = $_GET["lesson_name"];
                $template_name = $_GET["template_name"];
                $ques_name = mysql_real_escape_string($_GET["ques_name"]);
                $extra_words = mysql_real_escape_string($_GET["extra_words"]);
                $option1 = mysql_real_escape_string($_GET["option1"]);
                $option2 = mysql_real_escape_string($_GET["option2"]);
                $option3 = mysql_real_escape_string($_GET["option3"]);
                $option4 =mysql_real_escape_string($_GET["option4"]);
                $answer = mysql_real_escape_string($_GET["answer"]);
                $media = mysql_real_escape_string($_GET["media"]);
                $voice = mysql_real_escape_string($_GET["voice"]);
               $voice_answer =  mysql_real_escape_string($_GET["voice_answer"]);
                $brick_name = $_GET["brick_name"];
                $last_sync_time = $_GET["last_sync_time"];
                $result = mysql_query("SELECT * FROM tbl_questions WHERE id=$id");
                $num_rows = mysql_num_rows($result);
                if($num_rows>0) 
                {
                    while ($row = mysql_fetch_array($result)) 
                    {
                      if($last_sync_time >= $row["updated"]) 
                      {
                         mysql_query("Update tbl_questions set ques_id='$ques_id',program_name='$program_name',level_name='$level_name',updated'='$current_date',lesson_name = '$lesson_name',template_name = '$template_name',ques_name = '$ques_name',extra_words='extra_words',option1 = '$option1',option2 = '$option2',option3 = '$option3',option4 = '$option4',answer = '$answer',media = '$media',voice = '$voice',voice_answer = '$voice_answer',brick_name = '$brick_name' where id='$id'");
                                            
                            $response["success"] = 1;
                            $response["message"] = "Row updated";
                      }
                      else
                      {
                            //question exists
                            $response["success"] = 1;
                            $response["message"] = "No action required";
                      }
                   }
                                
               }
               else
               {
                    $result1 = mysql_query("INSERT INTO tbl_questions (id,ques_id,program_name,level_name,lesson_name,template_name,ques_name,extra_words,option1,option2,option3,option4,answer,media,voice,voice_answer,brick_name,updated) VALUES ('$id','$ques_id','$program_name','$level_name','$lesson_name','$template_name','$ques_name','$extra_words','$option1','$option2','$option3','$option4','$answer','$media','$voice','$voice_answer','$brick_name','$current_date')");
                   if($result1) 
                    {
                        $response["success"] = 1;
                    } 
                    else 
                    {
                        $response["success"] = 0;
                    }
                }
        }
        elseif($tableName == "tbl_passscore") {
                $id = $_GET["id"];
                $pass_percentage = $_GET["pass_percentage"];
                $brick_id = $_GET["brick_id"];

                $result = mysql_query("INSERT INTO tbl_passscore (id,pass_percentage,brick_id) VALUES ('$id','$pass_percentage','$brick_id')");
                if ($result) {
                                $response["success"] = 1;
                                echo json_encode($response);
                        } else {
                                $response["success"] = 0;
                                echo json_encode($response);
                        }
        }

        elseif($tableName == "tbl_pathway") {
                $id = $_GET["id"];
                $userid = $_GET["userid"];
                $subject_name = $_GET["subject_name"];
                $program_name = $_GET["program_name"];
                $level_name = $_GET["level_name"];
                $lesson_name = $_GET["lesson_name"];
                $lesson_no = $_GET["lesson_no"];
                $brick_level = $_GET["brick_level"];
                $date_val = $_GET["date_val"];
                $status = $_GET['status'];
                $created = $_GET['created'];
                $current_date = $_GET['current_date'];
                $last_sync_time = $_GET["last_sync_time"];
                $result = mysql_query("SELECT * FROM tbl_pathway WHERE id='$id'");
                $num_rows = mysqli_num_rows($result);
                if($num_rows>0) 
                {
                    while ($row = mysql_fetch_array($result)) 
                    {
                      if($last_sync_time >= $row["updated"]) 
                      {
                         mysql_query("Update tbl_pathway set userid = '$userid',subject_name='$subject_name',program_name='$program_name',level_name='$level_name',updated'='$current_date',lesson_name = '$lesson_name',lesson_no = '$lesson_no',brick_level = '$brick_level',date_val='date_val',status = '$status' where id='$id'");
                                            
                            $response["success"] = 1;
                            $response["message"] = "Row updated";
                      }
                      else
                      {
                            //pathway exists
                            $response["success"] = 1;
                            $response["message"] = "No action required";
                      }
                   }
                                
               }
               else
               {

                    $result = mysql_query("INSERT INTO tbl_pathway (id,userid,subject_name,program_name,level_name,updated,lesson_name,lesson_no,brick_level,dateVal,status) VALUES ('$id','$userid','$subject_name','$program_name','$level_name','$current_date','$lesson_name','$lesson_no','$brick_level','$date_val','$status')");
                    if ($result) 
                    {
                        $response["success"] = 1;
                    } 
                    else 
                    {
			//$response['error'] = mysql_error();
                        $response["success"] = 11;
                    }
                }
        }

        elseif($tableName == "tbl_scores") {
                $id = $_GET["id"];
                $userid = $_GET["userid"];
                $subject_name = $_GET["subject_name"];
                $program_name = $_GET["program_name"];
                $level_name = $_GET["level_name"];
                $lesson_name = $_GET["lesson_name"];
                $lesson_no = $_GET["lesson_no"];
                $score = $_GET["score"];
                $status = $_GET['status'];
                $start_date = $_GET['start_date'];
                $attempt_date = $_GET['attempt_date'];
                $time = $_GET['time'];
                $max_marks = $_GET['max_marks'];
                $pass_status = $_GET['pass_status'];
                $updated = $_GET['updated'];
                $brick_id = $_GET['brick_id'];
                $last_sync_time = $_GET["last_sync_time"];
                $result = mysql_query("SELECT * FROM tbl_scores WHERE id='$id'");
                $num_rows = mysql_num_rows($result);
                if($num_rows>0) 
                {
                    while ($row = mysql_fetch_array($result)) 
                    {
                      if($last_sync_time >= $row["updated"]) 
                      {
                         mysql_query("Update tbl_scores set userid = '$userid',subject_name='$subject_name',program_name='$program_name',level_name='$level_name',updated'='$current_date',lesson_name = '$lesson_name',lesson_no = '$lesson_no',score = '$score',start_date = '$start_date',status = '$status',attempt_date = '$attempt_date',time = '$time',max_marks = '$max_marks',pass_status = '$pass_status',brick_id = '$brick_id' where id='$id'");
                                            
                            $response["success"] = 1;
                            $response["message"] = "Row updated";
                      }
                      else
                      {
                            //pathway exists
                            $response["success"] = 1;
                            $response["message"] = "No action required";
                      }
                   }
                                
               }
               else
               {
                    $result = mysql_query("INSERT INTO tbl_scores (id, userid, subject_name, program_name, level_name, lesson_name, lesson_no, score, status, start_date, attempt_date, time, max_marks, pass_status, updated, brick_id) VALUES ('$id', '$userid', '$subject_name', '$program_name', '$level_name', '$lesson_name', '$lesson_no', '$score', '$status', '$start_date', '$attempt_date', '$time', '$max_marks', '$pass_status', '$current_date', '$brick_id')");
                    if ($result) 
                    {
                        $response["success"] = 1;
                    } else 
                    {
                        $response["success"] = 0;
                    }
               }
        }

        elseif($tableName == "tbl_quiz_dates") {
                $id = $_GET["id"];
                $userid = $_GET["userid"];
                $subject_name = $_GET["subject_name"];
 		$program_name = $_GET["program_name"];
                $level_name = $_GET["level_name"];
                $lesson_name = $_GET["lesson_name"];
                $lesson_no = $_GET["lesson_no"];
                $status = $_GET['status'];
                $start_date = $_GET['start_date'];
                $attempt_date = $_GET['attempt_date'];
                $created = $_GET['created'];

                $result = mysql_query("INSERT INTO tbl_quiz_dates (id, userid, subject_name, program_name, level_name, lesson_name, lesson_no, status, start_date, attempt_date, created) VALUES ('$id', '$userid', '$subject_name', '$program_name', '$level_name', '$lesson_name', '$lesson_no', '$status', '$start_date', '$attempt_date', '$current_date')");
                if ($result) {
                                $response["success"] = 1;
                                echo json_encode($response);
                        } else {
                                $response["success"] = 0;
                                echo json_encode($response);
                }
        }

}

//$response ="hello";
echo json_encode($response);
?>
